﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShopBridge.Controllers;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopBridge.Tests.Controllers
{
    [TestClass]
    public class ProductControllerTest
    {
        public ProductControllerTest()
        {

        }

        [TestMethod]
        public void TestIndexView()
        {
            //Arrange
            var controller = new ProductController();

            //Act
            var result = controller.Index() as ViewResult;

            //Assert
            Assert.AreEqual("Index", result.ViewName);

        }

        //[TestMethod]
        public void TestDisplayProductInformationView()
        {
            //Arrange
            var controller = new ProductController();

            //Act
            var result = controller.DisplayProductInformation(1) as ViewResult;

            //Assert
            Assert.AreEqual("DisplayProductInformation", result.ViewName);

        }

        //[TestMethod]
        public void TestDisplayProductInformationViewData()
        {
            //Arrange
            var controller = new ProductController();

            //Act
            var result = controller.DisplayProductInformation(1) as ViewResult;
            var product = (Product)result.ViewData.Model;

            //Assert
            Assert.AreEqual("Pen", product.Name);
            Assert.AreEqual("Parker Pen", product.Description);
            Assert.AreEqual(10, product.Price);
        }


    }
}
